docker exec -it ws /bin/sh -c 'UUID="$(/xray uuid)" && echo "UUID: $UUID"'
