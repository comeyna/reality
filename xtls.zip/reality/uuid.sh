docker exec -it xtls /bin/sh -c 'UUID="$(/xray uuid)" && echo "UUID: $UUID"'
