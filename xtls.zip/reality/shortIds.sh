openssl rand -hex 4
openssl rand -hex 8
