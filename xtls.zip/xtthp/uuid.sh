docker exec -it xhttp /bin/sh -c 'UUID="$(/xray uuid)" && echo "UUID: $UUID"'
